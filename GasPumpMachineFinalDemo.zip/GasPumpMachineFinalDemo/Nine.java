import java.lang.*;
import greenfoot.*;  
// (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class One here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nine extends Keypad implements KeypadHandlerInterface
{
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
      
        /*if(Greenfoot.mouseClicked(this))
        {
            System.out.println("One");
        }*/
    }    
    public String handleRequest( String request ) {
        String b="10";
            System.out.println("Before nine");
            System.out.println(this.toString());
            if(request.contains("Nine"))
            {
            System.out.println("In nine");
            b="9";
            }
			else
			{
            if ( successor != null )
                b=successor.handleRequest(request);
	
			}

        return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    }
    
    public static void sayTest()
    {
        System.out.println("Test");
    }

}
