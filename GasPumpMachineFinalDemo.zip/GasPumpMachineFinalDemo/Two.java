import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Two here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Two extends Keypad implements KeypadHandlerInterface
{
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
    }    
    public String handleRequest( String request ) {
        String b="10";
    System.out.println("Before Two");
            System.out.println(this.toString());
            if(request.contains("Two"))
            {
             System.out.println("In Two");
             b="2";
        }
            else
            {
            if ( successor != null )
                b=successor.handleRequest(request);
    
            }

   return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    }  
}
