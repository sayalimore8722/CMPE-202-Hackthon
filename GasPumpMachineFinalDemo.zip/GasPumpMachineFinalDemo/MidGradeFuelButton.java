import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MidGradeFuelButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MidGradeFuelButton extends Button
{
    GasPumpMachine gs;
    public MidGradeFuelButton(GasPumpMachine gs){
         this.gs = gs;
    }
    public MidGradeFuelButton(){
        GreenfootImage image =getImage();
        image.scale(50,60);
    }
    public void act() 
    {
        if(Greenfoot.mousePressed(this)){
            gs.selectedFuelType="MidGrade";
            if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){
                gs.setMessage("Remove Nozzle ",getWorld());
            }else if(GasPumpMachine.getCurrentScreen().toString().contains("EnterZipScreen")){
                gs.setMessage("Validate your card first ",getWorld());
            }
        }
    }    
}
