import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GasPumpWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public GasPumpWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 700, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        MeterReading r1 = new MeterReading();
        addObject(r1,502,60);
        r1.setLocation(456,56);

        CostReading c1 = new CostReading();
        addObject(c1,806,342);
        c1.setLocation(547,56);
        
        GasPumpMachine gaspumpmachine = new GasPumpMachine(r1,c1);
        addObject(gaspumpmachine,528,409);
        gaspumpmachine.setLocation(500,358);

      

        Nozzle nozzle = new Nozzle(gaspumpmachine,r1,c1);
        addObject(nozzle,504,265);
        nozzle.setLocation(357,317);

        ValidCard validcard = new ValidCard();
        addObject(validcard,834,125);
        validcard.setLocation(916,55);
        InvalidCard invalidcard = new InvalidCard();
        addObject(invalidcard,926,364);
        invalidcard.setLocation(915,161);

        MenuButton menubutton = new MenuButton(gaspumpmachine);
        addObject(menubutton,357,148);
        menubutton.setLocation(357,134);
        MenuButton menubutton2 = new MenuButton(gaspumpmachine);
        addObject(menubutton2,360,187);
        menubutton2.setLocation(356,174);
        MenuButton menubutton3 = new MenuButton(gaspumpmachine);
        addObject(menubutton3,362,228);
        menubutton3.setLocation(356,213);
        MenuButton menubutton4 = new MenuButton(gaspumpmachine);
        addObject(menubutton4,367,265);
        menubutton4.setLocation(357,251);
        MenuButton menubutton5 = new MenuButton(gaspumpmachine);
        addObject(menubutton5,654,142);
        menubutton5.setLocation(645,133);
        MenuButton menubutton6 = new MenuButton(gaspumpmachine);
        addObject(menubutton6,647,187);
        menubutton6.setLocation(645,172);
        MenuButton menubutton7 = new MenuButton(gaspumpmachine);
        addObject(menubutton7,652,224);
        menubutton7.setLocation(644,212);
        MenuButton menubutton8 = new MenuButton(gaspumpmachine);
        addObject(menubutton8,657,266);
        menubutton8.setLocation(644,255);

        CardHolder cardholder = new CardHolder();
        addObject(cardholder,630,388);
        cardholder.setLocation(619,383);

        One one = new One();
        addObject(one,444,340);
        one.setLocation(438,330);
        Two two = new Two();
        addObject(two,495,339);
        two.setLocation(491,331);
        Three three = new Three();
        addObject(three,551,339);
        three.setLocation(547,331);
        Back back = new Back();
        addObject(back,458,443);
        back.setLocation(437,444);
        Enter enter = new Enter();
        addObject(enter,564,454);
        enter.setLocation(551,445);
        Zero zero = new Zero();
        addObject(zero,503,452);
        zero.setLocation(494,444);
        Four four = new Four();
        addObject(four,441,384);
        four.setLocation(438,373);
        Five five = new Five();
        addObject(five,500,387);
        five.setLocation(491,374);
        Six six = new Six();
        addObject(six,552,384);
        six.setLocation(548,375);
        Seven seven = new Seven();
        addObject(seven,451,423);
        seven.setLocation(437,409);
        four.setLocation(438,368);
        seven.setLocation(438,406);
        back.setLocation(438,447);
        one.setLocation(438,327);
        four.setLocation(438,368);
        seven.setLocation(438,408);
        zero.setLocation(494,449);
        Eight eight = new Eight();
        addObject(eight,497,426);
        eight.setLocation(490,412);
        two.setLocation(491,328);
        three.setLocation(547,329);
        five.setLocation(491,369);
        eight.setLocation(490,408);
        zero.setLocation(490,448);
        six.setLocation(545,370);
        three.setLocation(548,327);
        cardholder.setLocation(606,385);
        six.setLocation(550,369);
        three.setLocation(551,326);
        two.setLocation(500,327);
        five.setLocation(500,367);
        one.setLocation(443,327);
        four.setLocation(443,368);
        seven.setLocation(443,407);
        back.setLocation(444,447);
        eight.setLocation(499,406);
        zero.setLocation(500,446);
        six.setLocation(553,368);
        Nine nine = new Nine();
        addObject(nine,570,419);
        nine.setLocation(554,407);
        nine.setLocation(553,407);
        enter.setLocation(552,445);

        cardholder.setLocation(619,385);

        UnleadedFuelButton unleadedfuelbutton = new UnleadedFuelButton(gaspumpmachine);
        addObject(unleadedfuelbutton,423,546);
        unleadedfuelbutton.setLocation(437,534);
        MidGradeFuelButton midgradefuelbutton = new MidGradeFuelButton(gaspumpmachine);
        addObject(midgradefuelbutton,531,547);
        midgradefuelbutton.setLocation(502,558);
        unleadedfuelbutton.setLocation(441,559);
        midgradefuelbutton.setLocation(502,559);
        PremiumFuelButton premiumfuelbutton = new PremiumFuelButton(gaspumpmachine);

        addObject(premiumfuelbutton,590,566);
        premiumfuelbutton.setLocation(562,559);
        Keypad keypad = new Keypad(gaspumpmachine,cardholder);
        addObject(keypad,661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(661,513);
        keypad.setLocation(963,685);

        SanJoseGasPump sanjosegaspump = new SanJoseGasPump();
        addObject(sanjosegaspump,88,90);
        SanFransciscoGasPump sanfransciscogaspump = new SanFransciscoGasPump();
        addObject(sanfransciscogaspump,91,167);
        PaloAltoGasPump paloaltogaspump = new PaloAltoGasPump();
        addObject(paloaltogaspump,94,238);
        sanfransciscogaspump.setLocation(123,72);
        sanjosegaspump.setLocation(107,167);
        sanfransciscogaspump.setLocation(130,80);
        sanjosegaspump.setLocation(100,160);
        paloaltogaspump.setLocation(100,240);
        PriceOfFuel priceoffuel = new PriceOfFuel();
        addObject(priceoffuel,388,64);
        priceoffuel.setLocation(385,56);
        FuelConsumption fuelconsumption = new FuelConsumption();
        addObject(fuelconsumption,649,58);
        fuelconsumption.setLocation(625,54);
        paloaltogaspump.setLocation(100,240);
        FuelPrice fuelprice = new FuelPrice();
        addObject(fuelprice,700,495);
        fuelprice.setLocation(510,501);
        premiumfuelbutton.setLocation(605,558);
        midgradefuelbutton.setLocation(510,559);
        unleadedfuelbutton.setLocation(405,559);
        menubutton7.setLocation(644,214);
        menubutton7.setLocation(644,213);
    }
}
