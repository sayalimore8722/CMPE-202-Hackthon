import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class IPinStateMachine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class IPinStateMachine {

    //current state
     private IPinState state ;
     private String d1, d2, d3, d4,d5;
     private int pinCount=0 ;
     //private String pin = "12345" ;
     //Keypad kp= new Keypad();
     
        private NoPinDigits pin0 ;
        private OnePinDigit pin1 ;
        private TwoPinDigits pin2 ;
        private ThreePinDigits pin3 ;
        private FourPinDigits pin4 ;
        private FivePinDigits pin5;
        
        public IPinStateMachine( )
        {
            pin0 = new NoPinDigits( this ) ;
            pin1 = new OnePinDigit( this ) ;
            pin2 = new TwoPinDigits( this ) ;
            pin3 = new ThreePinDigits( this ) ;
            pin4 = new FourPinDigits( this ) ;
            pin5= new FivePinDigits(this);
            this.state = pin0 ;
        }

        
        
    
     public void backspace() {
            this.state.backspace() ;
        }

        public void number( String digit ) {
            this.state.number( digit ) ;
        }

        public void validPin() {
            this.state.validPin() ;
        }

        public void invalidPin() {
            this.state.invalidPin() ;
        }
        
       /* public void setStateNoPinDigits()
        {
            this.state = pin0 ;
            Keypad.digits.add("");
        }
        public void setStateOnePinDigit( String digit )
        {
            this.state = pin1 ;
            if ( digit != null )
                Keypad.digits.set(0,digit);
            else
                
            debug() ;
            
        }
        public void setStateTwoPinDigits( String digit )
        {
            this.state = pin2 ;
            if ( digit != null )
                Keypad.digits.set(1,digit);
            else
            debug();
        }
         public void setStateThreePinDigits( String digit )
        {
            this.state = pin3;
           if ( digit != null )
                Keypad.digits.set(2,digit);
            else
            debug();
        }
        public void setStateFourPinDigits( String digit )
        {
            this.state = pin4;
             if ( digit != null )
                Keypad.digits.set(3,digit);
            else
            debug();
        }
        public void setStateFivePinDigits( String digit )
        { 
            this.state = pin5;
             if ( digit != null )
                Keypad.digits.set(4,digit);
            else
            debug();
            
        }
        */
        public void setStateNoPinDigits()
        {
            this.pinCount = 0 ;
            this.state = pin0 ;
            this.d1 = "" ;
            this.d2 = "" ;
            this.d3 = "" ;
            this.d4 = "" ;
            this.d5= "";
           debug() ;
        }

        public void setStateOnePinDigit( String digit )
        {
            this.pinCount = 1 ;
            this.state = pin1 ;
            if ( digit != null )
            
                this.d1 = digit ;
               
            else
                this.d2 = "" ;
            debug() ;
        }

        public void setStateTwoPinDigits( String digit )
        {
            this.pinCount = 2 ;
            this.state = pin2 ;
            if ( digit != null )
                this.d2 = digit ;
            else
                this.d3 = "" ;
            debug() ;
        }

        public void setStateThreePinDigits( String digit )
        {
            this.pinCount = 3 ;
            this.state = pin3 ;
            if ( digit != null )
                this.d3 = digit ;
            else
                this.d4 = "" ;
            debug() ;
        }

        
        public void setStateFourPinDigits( String digit )
        {
            this.pinCount = 4 ;
            this.state = pin4 ;
            if ( digit != null )
                this.d4 = digit ;
            else
                this.d5 = "" ;
            debug() ;
        }
        
        public void setStateFivePinDigits( String digit )
        {
            this.pinCount = 5 ;
            this.state = pin5 ;
            int i=5;
            if ( digit != null )
            {
                this.d5 = digit ;
                debug() ;
               System.out.println( "Authenticating..." ) ;
               if ( i==5 )
                {
                    System.out.println( "Successful Login!" ) ;
                    
                   
                }
                else
                {
                    System.out.println( "Login Failed!" ) ;
                    setStateNoPinDigits() ;
                
            }
        }
       }
       /* 
        private void debug()
        {
            System.out.println( "Current State: " + state.getClass().getName() ) ;
            System.out.println( "D1 = " + Keypad.digits.get(0) ) ;
            System.out.println( "D2 = " + Keypad.digits.get(1) ) ;
            System.out.println( "D3 = " + Keypad.digits.get(2) ) ;
            System.out.println( "D4 = " +  Keypad.digits.get(3)) ;
            System.out.println("D5= "+Keypad.digits.get(4));
        }
        
        
    */
   
   private void debug()
        {
            System.out.println( "Current State: " + state.getClass().getName() ) ;
           /* System.out.println( "D1 = " + d1) ;
            System.out.println( "D2 = " + d2 ) ;
            System.out.println( "D3 = " + d3 ) ;
            System.out.println( "D4 = " +  d4) ;
            System.out.println("D5= "+d5);*/
        }
       }
    



