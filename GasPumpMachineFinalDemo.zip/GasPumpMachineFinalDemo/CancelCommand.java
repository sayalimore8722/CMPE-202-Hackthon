import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CancelCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CancelCommand implements Command{
  Screen receiver;
  
  public CancelCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  public void execute(World world){
    receiver.rightButtonClicked(world);
  }
}
