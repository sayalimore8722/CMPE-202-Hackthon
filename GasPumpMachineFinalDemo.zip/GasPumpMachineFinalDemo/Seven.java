import java.lang.*;
import greenfoot.*;  
// (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class One here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Seven extends Keypad implements KeypadHandlerInterface
{
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
      
        /*if(Greenfoot.mouseClicked(this))
        {
            System.out.println("One");
        }*/
    }    
    public String handleRequest( String request ) {
        String b="10";
            System.out.println("Before seven");
            System.out.println(this.toString());
            if(request.contains("Seven"))
            {
            System.out.println("In seven");
            b="7";
            }
			else
			{
            if ( successor != null )
                b=successor.handleRequest(request);
	
			}

        return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    }
    
    public static void sayTest()
    {
        System.out.println("Test");
    }

}
