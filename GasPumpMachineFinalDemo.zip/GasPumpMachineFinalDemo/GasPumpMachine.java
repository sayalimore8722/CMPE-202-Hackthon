import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class GasPumpMachine extends Actor
{
   
    Message m = new Message();
    CreditCard validCard;
    Actor haveCard;
    //Keypad key = new Keypad(this);
    static Screen currentScreen;
    
    //Receipt variables
    Boolean printReceipt=false;
    String selectedFuelType;
    static String scenario;
    private MeterReading r1;
    private CostReading c1;
    public GasPumpMachine( MeterReading r,CostReading c){
         r1=r;
         c1=c;
        //System.out.println("me adhi: ");
        //World world = getWorld();
        GreenfootImage image =getImage();
        image.scale(500,700); 
        //Keypad key = new Keypad(this);
        //setMessage("Insert Card !",world);
    }
    
    public void setMessage( String msg, World world)
    {
     
       //int mouseX, mouseY ; 
       //MouseInfo mouse = Greenfoot.getMouseInfo();
       //System.out.println("setMessage: "+msg);
       //System.out.println("***"+mouse);
       //mouseX = mouse.getX();
       //mouseY = mouse.getY();
      
       if ( m.getWorld() != null )
       {
           world.removeObject( m) ;
           //System.out.println("world:" +world);
           
        }
        world.addObject( m, 500, 190 ) ;
       
        m.setText( msg );
    }
    
    public void act() 
    {
        
        World world = getWorld();
        //setMessage( "Insert Card",world ) ;
        Actor creditCard = getOneObjectAtOffset( +10, -10, CreditCard.class) ;
        if ( Greenfoot.mousePressed(this))
        {
            if ( haveCard == null ){
                setMessage( "Insert Card",world ) ;
            }
            else
                {
                   // if (validCard == creditcard.getClass())
                    
                //setMessage( "Crank Turned!",world);
                //setMessage("Enter Zip",world) ;
            
                //key.validateZip(world); 
            }
        }
        
        if ( creditCard!= null )
        {
            // validCard = creditCard.getClass();
            if ( haveCard != null)
            {
                creditCard.move( +40 ) ;
            }
            else
            {
               
                //if ( validCard != null)
                //{
                    haveCard = creditCard ;
                    currentScreen = new EnterZipScreen(this);
                    currentScreen.display(world);
                    
                    
                    //setMessage("Enter Zip",world) ;
                    //z.enterZip(world);
                    
                    
                    
                /*}
                else
                {
                     setMessage("Insert Valid Card !",world) ;
                }*/
               // System.out.println("Coin"+haveCoin);
               // ((Coin)coin).inSlot() ;
            }
        }
        
    
        // Add your action code here.
    }
    
    public static Screen getCurrentScreen(){
        return currentScreen;
    }
    
    public void resetGasPumpMachine(){
        r1.setValue(0);
        c1.setValue(0);
        setMessage("Insert Card ",getWorld());
        
        currentScreen = new EnterZipScreen(this);
        this.printReceipt=false;
        this.selectedFuelType="";
        this.haveCard=null;
        this.validCard=null;
        
                
                
      
           
         
        //GasPumpWorld g = new GasPumpWorld();
        //GasPumpWorld.resetCardObjects();
        
    }


}
