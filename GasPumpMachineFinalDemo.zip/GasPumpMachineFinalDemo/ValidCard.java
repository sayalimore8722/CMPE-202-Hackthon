import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ValidCard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ValidCard extends CreditCard
{
    /**
     * Act - do whatever the ValidCard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public ValidCard() 
    {
        GreenfootImage image =getImage();
        image.scale(150,100);
  
    }
    
    
}
