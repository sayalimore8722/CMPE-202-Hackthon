import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WashCarCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CarWashCommand implements Command{
   
   Screen receiver;
  
  public CarWashCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  
  public void execute(World world){
        receiver.leftButtonClicked(world);
  }  
}
