import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CardHolder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CardHolder extends Actor
{
    int flag = 0;
    public CardHolder(){
        
        GreenfootImage image =getImage();
        image.scale(80,120);
        GasPumpMachine gs;
    }
    public void act() 
    {
        // Add your action code here.
    } 
    public int check()
    {
        Actor touch=getOneIntersectingObject(ValidCard.class);
        if(touch!=null)
        {
            flag=1;
        }
        else
        {
            flag=0;
        }
        return flag;
    }
}
