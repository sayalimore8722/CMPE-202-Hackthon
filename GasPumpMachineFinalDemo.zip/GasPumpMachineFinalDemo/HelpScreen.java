import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HelpScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelpScreen extends Screen
{
    GasPumpMachine gs;
    
    public HelpScreen(GasPumpMachine gs){
         this.gs = gs;
    }
    
   public void leftButtonClicked(World world){
         
        gs.currentScreen = new FuelTypeSelectionScreen(gs);
        gs.currentScreen.display(world);
   }
   
   public void rightButtonClicked(World world){
     
   }
   
   public void display(World world){
      gs.setMessage("Usage:Insert Card->\nEnter Zip->\nSelect Fuel Type \nBack",world);
    }
}
