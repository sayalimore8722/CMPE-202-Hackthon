import java.lang.*;
import greenfoot.*;  
import java.util.*;
// (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class One here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enter extends Keypad implements KeypadHandlerInterface
{
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
      
        /*if(Greenfoot.mouseClicked(this))
        {
            System.out.println("One");
        }*/
    }    
    public String handleRequest( String request ) {
        String b="10";
            System.out.println("Before Enter");
            System.out.println(this.toString());
            if(request.contains("Enter"))
            {
            System.out.println("In enter");
            b="100";
            }
			else
			{
            if ( successor != null )
                b=successor.handleRequest(request);
	
			}

        return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    }
    
    public  void Enter(ArrayList<String> digits)
    {
        IPinStateMachine ipin=new IPinStateMachine();
        System.out.println("digits"+digits);
        if(digits.size()==5)
        {
            System.out.println("Successful login");
        }
        else
        {
            System.out.println("digits"+digits.size());
            System.out.println("login failed");
            digits.clear();
           /* for(int i=0;i<digits.size();i++)
          
            {
                System.out.println("check++++"+i);
                System.out.println("check"+digits.get(i));
                digits.remove(i);
                
                
            }*/
            System.out.println("digitsfinal "+digits);
           ipin.setStateNoPinDigits() ;
        }
    }

}
