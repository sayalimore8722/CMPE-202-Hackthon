import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BackCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackCommand implements Command{
  Screen receiver;
  
  public BackCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  
  public void execute(World world){
        receiver.leftButtonClicked(world);
  }
}
