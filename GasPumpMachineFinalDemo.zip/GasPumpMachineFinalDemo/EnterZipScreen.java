/**
 * Write a description of class InsertCardScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import greenfoot.*;


public class EnterZipScreen extends Screen 
{
    // instance variables - replace the example below with your own
    private int x;
    //World world = getWorld();
    GasPumpMachine gs;
    public EnterZipScreen(GasPumpMachine gs){
         this.gs = gs;
    }
    public void act()
    {
    }
  public void leftButtonClicked(World world){
     
   }
   
   public void rightButtonClicked(World world){
     
   }
  
   public void display(World world){
       //System.out.println("World in insertcard:"+world);
       gs.setMessage("Enter Zip...",world);
       
    }
}
