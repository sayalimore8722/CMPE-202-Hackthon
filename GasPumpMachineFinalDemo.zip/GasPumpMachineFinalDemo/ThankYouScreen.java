import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CarWashScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ThankYouScreen extends Screen
{
    GasPumpMachine gs;
    
    public ThankYouScreen(GasPumpMachine gs){
         this.gs = gs;
    }
    
   public void leftButtonClicked(World world){
         //gs.setMessage("Car Wash will \n start shortly.. ",world);
         //Give delay for car wash
        //Greenfoot.delay(300);
        //After car wash is complete, go to Help Screen
        //gs.currentScreen = new FuelTypeSelectionScreen(gs);
        gs.currentScreen.display(world);
   }
   
   public void rightButtonClicked(World world){
     //gs.setMessage("You chose to cancel ",world);
      //gs.currentScreen = new PrintReceiptScreen(gs);
        gs.currentScreen.display(world);
   }
   
   public void display(World world){
       gs.setMessage("\n\n\n \t\t\t Thank You...",world);
    }
}
