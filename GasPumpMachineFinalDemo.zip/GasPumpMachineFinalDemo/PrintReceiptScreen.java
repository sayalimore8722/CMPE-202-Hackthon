import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PrintReceiptScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PrintReceiptScreen extends Screen{
   GasPumpMachine gs;
    
    public PrintReceiptScreen(GasPumpMachine gs){
         this.gs = gs;
    }
    
   public void leftButtonClicked(World world){
       gs.printReceipt= true;
       if(GasPumpMachine.scenario == "SanJoseGasPump" || GasPumpMachine.scenario == "PaloAltoGasPump"){
                gs.currentScreen = new FuelTypeSelectionScreen(gs);
                gs.currentScreen.display(world);
       }else if(GasPumpMachine.scenario == "SanFransiscoGasPump"){
           gs.setMessage("Printing Receipt...", world);
           Greenfoot.delay(100);
           gs.currentScreen = new ThankYouScreen(gs);
           gs.currentScreen.display(world);
           Greenfoot.delay(500);
                
           //Reset gaspumpmachine
           gs.resetGasPumpMachine();
        }
       
      
       
     }
   
   public void rightButtonClicked(World world){
     //gs.setMessage("You chose to not print receipt ",world);
     //If no print receipt, go to Help Screen
     if(GasPumpMachine.scenario == "SanJoseGasPump" || GasPumpMachine.scenario == "PaloAltoGasPump"){
        gs.currentScreen = new FuelTypeSelectionScreen(gs);
        gs.currentScreen.display(world);
    }else if(GasPumpMachine.scenario == "SanFransiscoGasPump"){
            
            gs.currentScreen = new ThankYouScreen(gs);
            gs.currentScreen.display(world);
            Greenfoot.delay(100);
                
           //Reset gaspumpmachine
           gs.resetGasPumpMachine();
    }
  
    
   }
   public void display(World world){
       gs.setMessage("\tDo you want to\n\tprint receipt ? \n\nYes \t\t\t\t\t\t\t\t\t No",world);
    }
    
    
    /*public float calculateGasPrice(){
        float price=0;
        if(gs.selectedFuelType == "Unleaded"){
            price = 2;
        }
        else if(gs.selectedFuelType == "Premium"){
            price = 3;
        }
        else if(gs.selectedFuelType == "MidGrade"){
            price = 2;
        }
        return price;
    }
    
    public String getReceipt(){
        String res="SHELL V-POWER \n ";
        res+="Fuel \t\t\t (G) \t\t\t ($\\G) \t\t\t ($) \n";
        res+= gs.selectedFuelType + " \t\t\t "+" 1 "+" \t\t\t "+2+" \t\t\t "+calculateGasPrice();
        
        return res;
    }*/
}
