import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PremiumFuelButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PremiumFuelButton extends Button
{
   
    GasPumpMachine gs;
    public PremiumFuelButton(GasPumpMachine gs){
         this.gs = gs;
    }
    public PremiumFuelButton(){
        GreenfootImage image =getImage();
        image.scale(50,60);
    }
    public void act() 
    {
        if(Greenfoot.mousePressed(this)){
            gs.selectedFuelType="Premium";
            if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){
                gs.setMessage("Remove Nozzle ",getWorld());
            }else if(GasPumpMachine.getCurrentScreen().toString().contains("EnterZipScreen")){
                gs.setMessage("Validate your card first ",getWorld());
            }
        }
    }    
}
