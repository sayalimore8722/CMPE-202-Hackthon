import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nozzle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nozzle extends Actor
{
    /**
     * Act - do whatever the Nozzle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GasPumpMachine gs;
    Actor nozzleremoved;
    int i;
    
    private MeterReading r1;
    private CostReading c1;
    public Nozzle(GasPumpMachine gs, MeterReading r,CostReading c){
        this.gs = gs;
         r1=r;
         c1=c;
        GreenfootImage image =getImage();
        image.scale(350,350);
        i=0;
    }
    
    
    public void act() 
    {
       int mouseX, mouseY ;
       World world = getWorld();
        
        if(Greenfoot.mouseDragged(this)) { 
            
            MouseInfo mouse = Greenfoot.getMouseInfo();  
            mouseX=mouse.getX();  
            mouseY=mouse.getY();  
            setLocation(mouseX, mouseY);  
            gs.setMessage("Nozzle Removed",world);
            System.out.println("zop: "+i);
            if(i<1)
            {
                
                r1.add(100);
                
            }
            
            if(i<1)
            {
                
                c1.add(65);
                
            }
           
            i++;
            
            
            if(GasPumpMachine.scenario == "SanJoseGasPump" || GasPumpMachine.scenario == "PaloAltoGasPump"){
              
            
                //Meter stopped, show Thankyou screen
                gs.currentScreen = new ThankYouScreen(gs);
                gs.currentScreen.display(world);
                Greenfoot.delay(100);
                
                //Reset gaspumpmachine
                gs.resetGasPumpMachine();
            }else if(GasPumpMachine.scenario == "SanFransiscoGasPump"){
                gs.currentScreen = new PrintReceiptScreen(gs);
                gs.currentScreen.display(world);
            }
            
            

           
        } 
        
    }  
    
      
}
