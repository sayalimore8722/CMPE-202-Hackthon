import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NoPinDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
   
public class NoPinDigits implements IPinState
{
    IPinStateMachine machine ;

    public NoPinDigits( IPinStateMachine m )
    {
        this.machine = m ;
    }

    public void backspace() {
    }

    public void number( String digit ) {
        machine.setStateOnePinDigit( digit ) ;
    }

    public void validPin() {
    }

    public void invalidPin() {
    }

}
 

