import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Write a description of class MenuButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuButton extends Actor implements Invoker{
  Command theCommand;
  GasPumpMachine gs;
  int mouseX, mouseY ;
  GreenfootSound beep = new GreenfootSound("beep.mp3");

    public MenuButton(Command c){
        this.theCommand=c;
    
        GreenfootImage image =getImage();
        image.scale(40,30);
 
  }
  public MenuButton(GasPumpMachine gs){
      this.gs = gs;
      GreenfootImage image =getImage();
        image.scale(40,30);
    }
    
    public MenuButton(){
     
    }
  
  public void act(){
      
      
      if(Greenfoot.mousePressed(this)){
            beep.play();
            
            MouseInfo mouse = Greenfoot.getMouseInfo();  
            mouseX=mouse.getX();  
            mouseY=mouse.getY();
            Actor actorClicked=Greenfoot.getMouseInfo().getActor();
            System.out.println("******menubutton pressed. current screen= "+GasPumpMachine.getCurrentScreen().toString());
            if(actorClicked.getX()==356 && actorClicked.getY()==213){//lhs button
                if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){ //Help button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new HelpCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                }
                else if(GasPumpMachine.getCurrentScreen().toString().contains("PrintReceiptScreen")){ //Yes button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new PrintReceiptCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                }
                else if(GasPumpMachine.getCurrentScreen().toString().contains("CarWashScreen")){ //Yes button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new CarWashCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                    
                    
                }
                else if(GasPumpMachine.getCurrentScreen().toString().contains("HelpScreen")){ //Back button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new BackCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                    
                    
                }
            }
            else if(actorClicked.getX()==644 && actorClicked.getY()==213){//rhs button
                //System.out.println("this is the top right button pressed");
                 if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){ //Cancel button pressed
                    Command c = new CancelCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                }
                else if(GasPumpMachine.getCurrentScreen().toString().contains("PrintReceiptScreen")){ //No button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new NoPrintReceiptCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                }
                else if(GasPumpMachine.getCurrentScreen().toString().contains("CarWashScreen")){ //No button pressed
                    //System.out.println("this is the pressed button"+" screen ="+GasPumpMachine.getCurrentScreen().toString());
                    Command c = new NoCarWashCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c;
                    this.press();
                }
            }
            /*else if(actorClicked.getX()==657){//right side last button
                 if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){ //Back button pressed
                    Command c = new BackCommand(GasPumpMachine.getCurrentScreen());
                    this.theCommand=c; 
                    this.press();
                }
            }*/
      }
  
  
}
  
  public void press(){
    theCommand.execute(getWorld());
  }
}
