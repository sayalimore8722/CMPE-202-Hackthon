import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class UnleadedFuelButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class UnleadedFuelButton extends Button
{
    /**
     * Act - do whatever the UnleadedFuelButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GasPumpMachine gs;
    public UnleadedFuelButton(GasPumpMachine gs){
         this.gs = gs;
    }
    
    public UnleadedFuelButton(){
        GreenfootImage image =getImage();
        image.scale(50,60);
    }
    public void act() 
    {
        if(Greenfoot.mousePressed(this)){
            gs.selectedFuelType="Unleaded";
            if(GasPumpMachine.getCurrentScreen().toString().contains("FuelTypeSelectionScreen")){
                gs.setMessage("Remove Nozzle ",getWorld());
            }else if(GasPumpMachine.getCurrentScreen().toString().contains("EnterZipScreen")){
                gs.setMessage("Validate your zip \nBefore selecting \nfuel type ",getWorld());
                Greenfoot.delay(100);
                gs.currentScreen = new EnterZipScreen(gs);
                gs.currentScreen.display(getWorld());
            }
        }
    }    
}
