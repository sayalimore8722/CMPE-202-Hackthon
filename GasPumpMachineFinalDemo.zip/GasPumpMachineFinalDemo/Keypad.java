
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class KeyPad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Keypad extends Actor
{
    /**
     * Act - do whatever the KeyPad wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public ArrayList<String> digits=new ArrayList<String>();
    IPinStateMachine ipin=new IPinStateMachine();
    String returned;
    World world = getWorld();
    Class key;
    int flag;
    
    MenuButton mn;
     
    
    //GasPumpMachince gs = new GasPumpMachine();
    GasPumpMachine gs;
    CardHolder ch;
    public Keypad(GasPumpMachine gs, CardHolder cd){
         this.gs = gs;
         this.ch = cd;
         
    }
    public Keypad(){
        GreenfootImage image =getImage();
        image.scale(40,35);
        
    }
    
      
      
    
       public void act() 
    {
        //System.out.println("Hello");
        //System.out.println("inside keypad");
        //gs.currentScreen = new HelpScreen(gs);
        
        //System.out.println("inside world :"+world);
        Enter e= new Enter();
        Back bk= new Back();
        KeypadHandlerInterface one=new One();
        KeypadHandlerInterface two=new Two();
        KeypadHandlerInterface three=new Three();
        KeypadHandlerInterface four=new Four();
        KeypadHandlerInterface five=new Five();
        KeypadHandlerInterface six=new Six();
        KeypadHandlerInterface seven=new Seven();
        KeypadHandlerInterface eight=new Eight();
        KeypadHandlerInterface nine=new Nine();
        KeypadHandlerInterface zero=new Zero();
        KeypadHandlerInterface enter=new Enter();
        KeypadHandlerInterface back=new Back();
        
        List<Keypad> keypad = new ArrayList<Keypad>();
        keypad = getWorld().getObjects(Keypad.class);
        //System.out.println(keypad);
        one.setSuccessor(two);
        two.setSuccessor(three);
        three.setSuccessor(four);
        four.setSuccessor(five);
        five.setSuccessor(six);
        six.setSuccessor(seven);
        seven.setSuccessor(eight);
        eight.setSuccessor(nine);
        nine.setSuccessor(zero);
        zero.setSuccessor(enter);
        enter.setSuccessor(back);
        
        //System.out.println("keysize"+keypad.size());
        //System.out.println("iiii");
  
         
        for(int i = 0; i<keypad.size();i++){
        if(Greenfoot.mousePressed(keypad.get(i)))
        {
            //System.out.println("keysize"+keypad.size());
            //System.out.println("iii"+i);
            World w=getWorld();
           int k=ch.check();
           if(k==0)
           {
               gs.setMessage("Insert Card",w);
            }
            else
            {
            
            System.out.println(keypad.get(i));
            returned=one.handleRequest(keypad.get(i).toString());
            System.out.println("******11111 ");
            System.out.println("b is: "+returned);
            if(returned!="10" && returned!="11" && returned!="100" && digits.size()<5)
            digits.add(returned);
            
            
            
            if(digits.size()==0)
            ipin.setStateNoPinDigits();
           else if (digits.size()==1 && returned!="10" && returned!="11" && returned!="100")
           {
            ipin.setStateOnePinDigit(returned);
            String zip_str="Enter Zip...\n\n\t\t"+"[*][ ][ ][ ][ ]";
            System.out.println(zip_str);
            System.out.println(gs);
            
            gs.setMessage(zip_str,w);
            //digits.add(returned);
           }
        else if(digits.size()==2 && returned!="10" && returned!="11" && returned!="100")
            
            {   ipin.setStateTwoPinDigits(returned);
               // digits.add(returned);
               String zip_str="Enter Zip...\n\n\t\t"+"[*][*][ ][ ][ ]";
            System.out.println(zip_str);
            System.out.println(gs);
            
            gs.setMessage(zip_str,w);
            }
            
            else if(digits.size()==3 && returned!="10" && returned!="11" && returned!="100" )
            {
                ipin.setStateThreePinDigits(returned);
               // digits.add(returned);
                String zip_str="Enter Zip...\n\n\t\t"+"[*][*][*][ ][ ]";
            System.out.println(zip_str);
            System.out.println(gs);
            
            gs.setMessage(zip_str,w);
            }
            else if(digits.size()==4 && returned!="10" && returned!="11" && returned!="100")
            {
                ipin.setStateFourPinDigits(returned);
               // digits.add(returned);
                String zip_str="Enter Zip...\n\n\t\t"+"[*][*][*][*][ ]";
            System.out.println(zip_str);
            System.out.println(gs);
            
            gs.setMessage(zip_str,w);
            }
            else if(digits.size()==5 && returned!="10" && returned!="11" && returned!="100")
            {
                ipin.setStateFivePinDigits(returned);
             //   digits.add(returned);
              String zip_str="Enter Zip...\n\n\t\t"+"[*][*][*][*][*]";
            System.out.println(zip_str);
            System.out.println(gs);
            
            gs.setMessage(zip_str,w);
            }
            
            System.out.println("size---"+digits.size());
            if(digits.size()==1)
            {
            System.out.println("D1 "+ digits.get(0));
        }
        else if(digits.size()==2)
        {
         System.out.println("D1 "+ digits.get(0)+"\n"+"D2 "+digits.get(1));   
        }
        else if(digits.size()==3)
        {
         System.out.println("D1 "+ digits.get(0)+"\n"+"D2 "+digits.get(1)+"\n"+"D3 "+digits.get(2));   
        }
        else if(digits.size()==4)
        {
         System.out.println("D1 "+ digits.get(0)+"\n"+"D2 "+digits.get(1)+"\n"+"D3 "+digits.get(2)+"\n"+"D4 "+digits.get(3));   
        }
        else if(digits.size()==5)
        {
         System.out.println("D1 "+ digits.get(0)+"\n"+"D2 "+digits.get(1)+"\n"+"D3 "+digits.get(2)+"\n"+"D4 "+digits.get(3)+"\n"+"D5 "+digits.get(4));   
        }
            if(returned=="11" && flag==0)
            {
                bk.back_Space(digits);
                if(digits.size()==0)
                {
                    String zip_str="Enter Zip...\n\n\t\t"+"[ ][ ][ ][ ][ ]";
                    System.out.println(zip_str);
                    System.out.println(gs);
            
                    gs.setMessage(zip_str,w);
                }
                else if(digits.size()==1)
                {
                    String zip_str="Enter Zip...\n\n\t\t"+"[*][ ][ ][ ][ ]";
                    System.out.println(zip_str);
                    System.out.println(gs);
            
                    gs.setMessage(zip_str,w);
                }
                 else if(digits.size()==2)
                {
                    String zip_str="Enter Zip...\n\n\t\t"+"[*][*][ ][ ][ ]";
                    System.out.println(zip_str);
                    System.out.println(gs);
            
                    gs.setMessage(zip_str,w);
                }
                 else if(digits.size()==3)
                {
                    String zip_str="Enter Zip...\n\n\t\t"+"[*][*][*][ ][ ]";
                    System.out.println(zip_str);
                    System.out.println(gs);
            
                    gs.setMessage(zip_str,w);
                }
                 else if(digits.size()==4)
                {
                    String zip_str="Enter Zip...\n\n\t\t"+"[*][*][*][*][ ]";
                    System.out.println(zip_str);
                    System.out.println(gs);
            
                    gs.setMessage(zip_str,w);
                }
                
            }
            
            if(returned=="100" && digits.size()==5)
            {
                e.Enter(digits);
                if(GasPumpMachine.scenario == "SanJoseGasPump"){
                    gs.currentScreen = new CarWashScreen(gs);
                    gs.currentScreen.display(w);
                }
                else if(GasPumpMachine.scenario == "SanFransiscoGasPump"){
                    System.out.println("******this is san fransisco gas pump");
                    gs.currentScreen = new FuelTypeSelectionScreen(gs);
                    gs.currentScreen.display(w);
                    //gs.setMessage("Nozzle Removed",w);
                }
                else{
                    gs.currentScreen = new PrintReceiptScreen(gs);
                    gs.currentScreen.display(w);
                }
            }
            
        }
    }
        
    }    
}
    
    
    public String keyPress(World world){
        
        return "Enter";
    }
    
    public void validateZip(World world)
    {
        
       
       
        
            
      
    }

    
}
