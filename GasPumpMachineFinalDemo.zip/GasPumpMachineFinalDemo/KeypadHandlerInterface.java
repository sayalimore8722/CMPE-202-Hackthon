import java.util.*;

public interface KeypadHandlerInterface  
{
   String handleRequest( String request);
	void setSuccessor(KeypadHandlerInterface next);  
}
