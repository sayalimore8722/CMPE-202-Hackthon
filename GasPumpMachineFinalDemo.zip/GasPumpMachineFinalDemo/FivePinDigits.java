import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FivePinDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FivePinDigits implements IPinState
{
    IPinStateMachine machine ;

    public FivePinDigits( IPinStateMachine m )
    {
        this.machine = m ;
    }

    public void backspace() {
        machine.setStateFourPinDigits( null ) ;
    }

    public void number( String digit ) {
        machine.setStateFivePinDigits( digit ) ;
    }

    public void validPin() {

    }

    public void invalidPin() {

    } 
}
