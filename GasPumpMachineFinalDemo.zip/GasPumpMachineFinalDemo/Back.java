import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Back here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Back extends Keypad implements KeypadHandlerInterface
{
    
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
    }    
    public String handleRequest( String request ) {
        String b="10";
        //Keypad k=new Keypad();
        System.out.println("Before Back");
        //System.out.println("digits size:"+digits.size());
            System.out.println(this.toString());
            if(request.contains("Back"))
            {
            System.out.println("In Back");
            b="11";    
        }
            /*else
            {
            if ( successor != null )
                b=successor.handleRequest(request);
    
            }*/

     return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    } 
    
    public void back_Space(ArrayList<String> digits)
    {
        
        
        System.out.println("ArraySize**"+digits.size());
       
        if(digits.size()==1)
        {
            digits.remove(0);
            ipin.setStateNoPinDigits();
            System.out.println("After back_space_array"+digits);
            //System.out.println("D1"+digits.get(0));
            System.out.println("After back_space size"+digits.size());
        }
        else if(digits.size()==2)
            {
                
                System.out.println("check0"+digits.get(0));
                System.out.println("check1"+digits.get(1));
                System.out.println("Before back_space_array"+digits);
                ipin.setStateOnePinDigit(digits.get(0));
                
                digits.remove(1);
                System.out.println("After back_space_array"+digits);
                System.out.println("D1  "+digits.get(0));
                System.out.println("After back_space size"+digits.size());
            }
        else if(digits.size()==3)
            {
                
                
               
                System.out.println("check0"+digits.get(0));
                System.out.println("check1"+digits.get(1));
                System.out.println("check2"+digits.get(2));
                System.out.println("Before back_space_array"+digits);
                ipin.setStateOnePinDigit(digits.get(0));
                ipin.setStateTwoPinDigits(digits.get(1));
                
                digits.remove(2);
                System.out.println("After back_space_array"+digits);
                System.out.println("After back_space size"+digits.size());
            }    
            
         else if(digits.size()==4)
            {
                System.out.println("check3"+digits.get(3));
         
                System.out.println("check0 "+digits.get(0));
                System.out.println("check1"+digits.get(1));
                System.out.println("check2"+digits.get(2));
                System.out.println("Before back_space_array"+digits);
                ipin.setStateOnePinDigit(digits.get(0));
                ipin.setStateTwoPinDigits(digits.get(1));
                ipin.setStateThreePinDigits(digits.get(2));
                
                digits.remove(3);
                System.out.println("After back_space_array"+digits);
                System.out.println("After back_space size"+digits.size());
            }    
          else if(digits.size()==5)
            {
                System.out.println("check0"+digits.get(0));
                System.out.println("check1"+digits.get(1));
                System.out.println("check2"+digits.get(2));
                System.out.println("check3"+digits.get(3));
                System.out.println("Before back_space_array"+digits);
                
                ipin.setStateOnePinDigit(digits.get(0));
                ipin.setStateTwoPinDigits(digits.get(1));
                ipin.setStateThreePinDigits(digits.get(2));
                ipin.setStateFourPinDigits(digits.get(3));
                digits.remove(4);
                System.out.println("After back_space_array"+digits);
                System.out.println("After back_space size"+digits.size());
            }  
        
        
    }

    
}
