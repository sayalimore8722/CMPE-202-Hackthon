import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FuelConsumption here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FuelConsumption extends PriceLables
{
    /**
     * Act - do whatever the FuelConsumption wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public FuelConsumption(){
         GreenfootImage image =getImage();
        image.scale(60,40);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
