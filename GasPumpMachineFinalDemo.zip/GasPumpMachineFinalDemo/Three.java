import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Three here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Three extends Keypad implements KeypadHandlerInterface
{
    private KeypadHandlerInterface successor=null;  
    public void act() 
    {
        // Add your action code here.
    }    
    public String handleRequest( String request ) {
        String b="10";
	System.out.println("Before three");
            System.out.println(this.toString());
            if(request.contains("Three"))
            {
            System.out.println("In Three");
            b="3";    
        }
			else
			{
            if ( successor != null )
                b=successor.handleRequest(request);
	
			}

     return b;
    }
    public void setSuccessor(KeypadHandlerInterface next) {
        this.successor = next ;
    }    
}
