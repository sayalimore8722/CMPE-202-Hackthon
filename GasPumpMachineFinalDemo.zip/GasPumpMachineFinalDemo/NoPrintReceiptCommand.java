import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NoPrintReceiptCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NoPrintReceiptCommand implements Command{
  Screen receiver;
  
  public NoPrintReceiptCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  public void execute(World world){
    receiver.rightButtonClicked(world);
  }
}
