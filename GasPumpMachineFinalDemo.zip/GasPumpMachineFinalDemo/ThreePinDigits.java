import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ThreePinDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ThreePinDigits implements IPinState
{
    IPinStateMachine machine ;

    public ThreePinDigits( IPinStateMachine m )
    {
        this.machine = m ;
    }

    public void backspace() {
        machine.setStateTwoPinDigits( null ) ;
    }

    public void number( String digit ) {
        machine.setStateFourPinDigits( digit ) ;
    }

    public void validPin() {

    }

    public void invalidPin() {

    }
       
}
