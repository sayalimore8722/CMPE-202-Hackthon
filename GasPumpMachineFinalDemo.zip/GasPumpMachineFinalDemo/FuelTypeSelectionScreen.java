import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HelpScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FuelTypeSelectionScreen extends Screen{
   
    GasPumpMachine gs;
    
    public FuelTypeSelectionScreen(GasPumpMachine gs){
         this.gs = gs;
    }
    
   public void leftButtonClicked(World world){//Help button click
         //gs.setMessage("Usage :\nThis is your help \n\n Back",world);
        gs.currentScreen = new HelpScreen(gs);
        gs.currentScreen.display(world);
   }
   
   public void rightButtonClicked(World world){ //Cancel button click
       gs.resetGasPumpMachine();
     
   }
      
   public void display(World world){
       gs.setMessage("\t\t Please select \n\t\t\t fuel type \n\nHelp \t\t\t\t\t\t Cancel ",world);
    }
}
