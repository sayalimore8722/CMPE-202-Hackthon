import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OnePinDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class OnePinDigit implements IPinState
{
    IPinStateMachine machine ;

    public OnePinDigit( IPinStateMachine m )
    {
        this.machine = m ;
    }

    public void backspace() {
        machine.setStateNoPinDigits() ;
    }

    public void number( String digit ) {
        machine.setStateTwoPinDigits( digit ) ;
    }

    public void validPin() {

    }

    public void invalidPin() {

    }
}

