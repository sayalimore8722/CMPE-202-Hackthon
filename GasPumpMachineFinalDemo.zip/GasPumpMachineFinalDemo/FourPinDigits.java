import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FourPinDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FourPinDigits implements IPinState
{
    IPinStateMachine machine ;

    public FourPinDigits( IPinStateMachine m )
    {
        this.machine = m ;
    }

    public void backspace() {

    }

    public void number( String digit ) {

    }

    public void validPin() {

    }

    public void invalidPin() {
        machine.setStateNoPinDigits() ;
    }
}
